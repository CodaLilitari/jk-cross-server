#!/usr/bin/env python3
"""Recompile bundled libsmacker source and relink supplied application objects."""
from pathlib import Path
import json, subprocess
root=Path(__file__).resolve().parent
for name in ['smacker','smk_bitstream','smk_hufftree']:
    subprocess.run(['cc','-O2','-fshort-wchar','-c',str(root/'libsmacker'/f'{name}.c'),'-o',str(root/'CMakeFiles/sith_engine.dir/src/external/libsmacker'/f'{name}.c.o')],check=True)
subprocess.run(json.loads((root/'link.json').read_text()),cwd=root,check=True)
print(root/'openjkdf2-relinked')
