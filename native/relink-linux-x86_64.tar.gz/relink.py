#!/usr/bin/env python3
"""Rebuild libsmacker and relink; optionally verify the exact supplied objects."""
from pathlib import Path
import argparse
import json
import subprocess

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--supplied-objects", action="store_true",
                    help="Skip library compilation and relink the packaged objects unchanged")
args = parser.parse_args()
root = Path(__file__).resolve().parent
if not args.supplied_objects:
    for name in ("smacker", "smk_bitstream", "smk_hufftree"):
        subprocess.run(["cc", "-O2", "-fshort-wchar", "-c",
                        str(root / "libsmacker" / (name + ".c")), "-o",
                        str(root / "CMakeFiles/sith_engine.dir/src/external/libsmacker" / (name + ".c.o"))],
                       check=True)
subprocess.run(json.loads((root / "link.json").read_text()), cwd=root, check=True)
for command in json.loads((root / "post-link.json").read_text()):
    subprocess.run(command, cwd=root, check=True)
print(root / "openjkdf2-relinked")
