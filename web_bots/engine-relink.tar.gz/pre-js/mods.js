// Full mods for the browser build: a folder of files the engine loads ahead
// of the game's own (`-path <folder>`, src/Main/jkRes.c), such as a saber
// mod. Bundled into openjkdf2.js after maps.js (cmake_modules/plat_wasm.cmake)
// and built on its transfer.
//
// The page (index.html) puts each mod folder it finds in the picked game
// folder under jkmods/ and starts the engine with the one the player chose.
// A host's lobby entry carries a short tail naming its mod: a name and a
// fingerprint, the SHA-256 of the mod packed into one GOB (pack()). The pack
// is built the same way everywhere, so the same files give the same
// fingerprint.
//
// A joiner whose mod isn't the host's gets the host's before the level loads:
// from a mod folder of its own with the same fingerprint, from one saved in an
// earlier game, or else from the host, sent the same way as a map (KIND_MOD
// frames). As with maps, original game files never cross the wire: every file
// in the pack that is a copy of a file in the retail GOBs, or of a whole
// retail GOB, is sent as a reference the joiner fills in from its own copy.
// Then the engine restarts into the mod in the same tab, and the player joins
// again with the game already selected (stdComm_WSRelay.c).
//
// Graphics packs (index.html's OPTIONAL_PACKS, such as JK HD Models.gob) are
// each player's own: the page puts the ones ticked in mods/, which the engine
// loads after -path whatever mod the game runs, so they're never part of the
// mod a host shares, a game with or without them needs no restart, and they
// stay on through a restart into the host's mod. The engine names textures
// in its messages by file name where a pack could shift their numbers
// (sithDSS.c), and checks a face number from another player against its
// own model (sithDSSThing.c), so players with and without one play together.

// Mods that came from a host are kept in IndexedDB and unpacked into
// netmods/<first 16 hex digits of the fingerprint> when needed, so they can
// be chosen next time from the folder prompt.
//
// A game watching a match (spectator mode, stdComm_WSRelay.c's view) whose
// mod isn't the match's gets onto it the same way, restarting: the host's mod
// from the player's own mod folders, one saved in this browser (from an
// earlier game or the Mod Library), the Mod Library's, when the host's
// keyframe names the library's id for it (libId(): a host's mod that the Mod
// Library saved), or else from the host's game by way of the match's feed,
// which asks it to put the mod there (feedUp, maps.js), sent as to a joiner
// with the original game files left out.
//
// The MotS Remastered pack (JKMRemasteredAssets.goo) isn't a mod the player
// picks: the page leaves it in mods/, which the engine always loads
// (index.html). Its files replace the game's own, with weapon and character
// scripts that play by other rules, and with models and textures that change
// the order the engine numbers sounds, models and textures in, which is how
// players' messages name them. So a game runs it as the host does: a joiner
// needs it when the host runs it, and runs without theirs when the host
// doesn't, restarting either way like for a mod. It's never sent: a joiner
// needs their own copy.
//
// The lobby tail, hex-encoded after the 240-byte jkMultiEntry:
//   "JKMD" <version u8> <flags u8> <name length u8>
//   [<mod fingerprint: 32 bytes>] [<pack fingerprint: 16 bytes>] <name>
// flags: 1 the host runs a mod, named by <name>; 2 it runs the Remastered
// pack, whose fingerprint is the first 16 bytes of its SHA-256. A host with
// neither sends no tail.

(function() {
    var maps = Module.jkMaps;
    if (!maps || !maps.core)
        return;
    var core = maps.core;
    var lib = maps.lib;
    var KIND_MOD = core.KIND_MOD;

    var TAIL_MAGIC = [0x4A, 0x4B, 0x4D, 0x44]; // "JKMD"
    var TAIL_VERSION = 2;
    var TAIL_MOD = 1, TAIL_PACK = 2;
    var MAX_NAME = 63;
    var PACK_FP_BYTES = 16;
    // What can be sent. Set by this page, not by the browser or the lobby: a
    // joiner holds the mod once as files and, for a moment, once more while
    // checking it, so 1 GB of mods needs about 2 GB of the tab's memory.
    // Bigger mods are still fingerprinted, so a joiner with the same folder can
    // use theirs.
    var MAX_MOD_BYTES = 1024 * 1024 * 1024;
    var MAX_MOD_FILES = 50000;
    var MAX_PACK_BYTES = 2047 * 1024 * 1024;
    var MAX_PACK_FILES = 50000;
    var MAX_STORED_MOD_BYTES = 2048 * 1024 * 1024;
    var MAX_PATH = 127; // a GOB entry name is char[128]
    var MAX_DEPTH = 8;
    var GOB_ENTRY = 136;
    // A pack of MAX_MOD_BYTES of files, with its header and table.
    var MAX_SEND_BYTES = MAX_MOD_BYTES + 16 + MAX_MOD_FILES * GOB_ENTRY;

    var store = core.makeStore('jkdf2mp-mods', MAX_STORED_MOD_BYTES);

    function FS() { return Module.FS; }

    function isMots() {
        return (Module['arguments'] || []).indexOf('-motsCompat') >= 0 || /\/mots$/.test(core.gameRoot());
    }

    function gameExt() { return isMots() ? 'goo' : 'gob'; }
    function gameName() { return isMots() ? 'mots' : 'jk1'; }

    function gameTitle(ext) {
        return ext === 'goo' ? 'Mysteries of the Sith' : 'Jedi Knight';
    }

    function isDir(path) {
        try { return FS().isDir(FS().stat(path).mode); } catch (e) { return false; }
    }

    // ---- The pack: every file of the mod in one GOB, in a fixed order.

    // Files that differ between copies of the same mod without mattering to
    // the game, so they'd only make two copies look different.
    function packable(rel) {
        var parts = rel.split('/');
        for (var p of parts) {
            if (p[0] === '.' || p.toLowerCase() === '__macosx')
                return false;
        }
        var base = parts[parts.length - 1].toLowerCase();
        return base !== 'thumbs.db' && base !== 'desktop.ini' &&
               !/\.(exe|dll|ico|ini|txt|url|pdf|htm|html|zip|rar|7z|bak|tmp)$/.test(base);
    }

    // A path a pack may hold: relative, at most MAX_DEPTH folders deep, and
    // nothing Windows wouldn't allow in a file name.
    function validRel(rel) {
        if (typeof rel !== 'string' || !rel.length || rel.length > MAX_PATH || !/^[\x20-\x7e]+$/.test(rel))
            return false;
        var parts = rel.split('/');
        if (parts.length > MAX_DEPTH + 1)
            return false;
        for (var p of parts) {
            if (!p || p === '.' || p === '..' || /[\\:*?"<>|]/.test(p) || /[ .]$/.test(p))
                return false;
        }
        return true;
    }

    // The mod's files under dir, sorted, as { rel, path, size }.
    function listFiles(dir) {
        var fs = FS();
        var out = [];
        (function walk(path, rel, depth) {
            var names = fs.readdir(path);
            for (var n of names) {
                if (n === '.' || n === '..')
                    continue;
                var p = path + '/' + n;
                var r = rel ? rel + '/' + n : n;
                var st = fs.stat(p);
                if (fs.isDir(st.mode)) {
                    if (depth < MAX_DEPTH && packable(r))
                        walk(p, r, depth + 1);
                } else if (fs.isFile(st.mode) && packable(r)) {
                    if (validRel(r))
                        out.push({ rel: r, path: p, size: st.size });
                    else
                        console.warn('OpenJKDF2: left out of the mod (name not shareable): ' + r);
                }
            }
        })(dir, '', 0);
        out.sort(function(a, b) { return a.rel < b.rel ? -1 : a.rel > b.rel ? 1 : 0; });
        return out;
    }

    function fail(reason) {
        return core.fail(reason);
    }

    // Packs the files into a GOB: "GOB ", version 20, the table's offset, the
    // files back to back, then the table (Win95/stdGob.h). In pieces: the
    // header, each file as readFile gives it, and the table, so nothing is
    // copied until the whole is needed in one piece (bytes()).
    function packPieces(files, readFile) {
        if (files.length > MAX_PACK_FILES)
            throw fail('too-many-files');
        var dataBytes = 0;
        for (var f of files)
            dataBytes += f.size;
        if (dataBytes > MAX_PACK_BYTES)
            throw fail('too-big');
        var tableOffs = 12 + dataBytes;
        var head = new Uint8Array(12);
        var hv = new DataView(head.buffer);
        head.set([0x47, 0x4F, 0x42, 0x20], 0);
        hv.setUint32(4, 20, true);
        hv.setUint32(8, tableOffs, true);
        var table = new Uint8Array(4 + files.length * GOB_ENTRY);
        var tv = new DataView(table.buffer);
        tv.setUint32(0, files.length, true);
        var parts = [head];
        var at = 12;
        var entries = [];
        files.forEach(function(f, i) {
            var bytes = readFile(f);
            if (bytes.length !== f.size)
                throw fail('changed');
            parts.push(bytes);
            var e = 4 + i * GOB_ENTRY;
            tv.setUint32(e, at, true);
            tv.setUint32(e + 4, f.size, true);
            for (var j = 0; j < f.rel.length; j++)
                table[e + 8 + j] = f.rel.charCodeAt(j);
            entries.push({ offset: at, size: f.size, name: f.rel });
            at += f.size;
        });
        parts.push(table);
        return { data: lib.pieces(parts), entries: entries, parts: parts };
    }

    function packFiles(files, readFile) {
        var p = packPieces(files, readFile);
        return { bytes: p.data.bytes(), entries: p.entries };
    }

    // The mod's files as the file system holds them, not copied.
    function readMod(f) {
        return core.fileBytes(f.path);
    }

    function pack(dir) {
        return packFiles(listFiles(dir), readMod);
    }

    // What a fingerprint was worked out from: each file's name, and the bytes
    // the file system holds for it. While they're the same arrays, the
    // fingerprint still holds and needn't be worked out again to host.
    function sameParts(a, b) {
        if (!a || !b || a.length !== b.length)
            return false;
        for (var i = 0; i < a.length; i++) {
            if (a[i].buffer !== b[i].buffer || a[i].byteOffset !== b[i].byteOffset || a[i].length !== b[i].length)
                return false;
        }
        return true;
    }

    function fileParts(p) {
        return p.parts.slice(1, -1);
    }

    // What may be sent as references: each file, and each file inside a GOB
    // the mod carries.
    function shareRanges(p) {
        var ranges = [];
        for (var e of p.entries) {
            ranges.push(e);
            if (!/\.go[bo]$/i.test(e.name))
                continue;
            var inner = p.data ? p.data.read(e.offset, e.size) : p.bytes.subarray(e.offset, e.offset + e.size);
            var dir = lib.parseGob(function(o, n) { return inner.subarray(o, o + n); }, inner.length);
            if (!dir)
                continue;
            for (var ie of dir.entries)
                ranges.push({ offset: e.offset + ie.offset, size: ie.size });
        }
        return ranges;
    }

    // Writes a pack's files into dir, after checking every name in it.
    function unpack(bytes, dir) {
        var gob = lib.parseGob(function(o, n) { return bytes.subarray(o, o + n); }, bytes.length);
        if (!gob)
            throw fail('corrupt');
        if (gob.entries.length > MAX_MOD_FILES)
            throw fail('too-many-files');
        var seen = {};
        for (var e of gob.entries) {
            var lower = e.name.toLowerCase();
            if (!validRel(e.name) || seen[lower])
                throw fail('bad-files');
            seen[lower] = true;
        }
        // A file and a folder can't share a name.
        for (var e of gob.entries) {
            var parts = e.name.toLowerCase().split('/');
            for (var i = 1; i < parts.length; i++) {
                if (seen[parts.slice(0, i).join('/')])
                    throw fail('bad-files');
            }
        }
        var fs = FS();
        try {
            fs.mkdirTree(dir);
            // Each file is a view of the pack, which the file system keeps.
            for (var e of gob.entries) {
                var path = dir + '/' + e.name;
                fs.mkdirTree(path.substring(0, path.lastIndexOf('/')));
                fs.writeFile(path, bytes.subarray(e.offset, e.offset + e.size), { canOwn: true });
            }
        } catch (err) {
            throw fail('install');
        }
        return gob.entries.length;
    }

    // ---- The lobby tail.

    function cleanName(name) {
        name = String(name || '').replace(/[^\x20-\x7e]/g, '?').trim();
        return (name || 'mod').substring(0, MAX_NAME);
    }

    // fp is the mod's fingerprint and name its name, or both null for none;
    // packFp is the Remastered pack's fingerprint, or null.
    function encodeTail(fp, name, packFp) {
        name = fp ? cleanName(name) : '';
        var at = 7;
        var b = new Uint8Array(at + (fp ? 32 : 0) + (packFp ? PACK_FP_BYTES : 0) + name.length);
        b.set(TAIL_MAGIC, 0);
        b[4] = TAIL_VERSION;
        b[5] = (fp ? TAIL_MOD : 0) | (packFp ? TAIL_PACK : 0);
        b[6] = name.length;
        function put(hex, n) {
            for (var i = 0; i < n; i++)
                b[at++] = parseInt(hex.substr(i * 2, 2), 16);
        }
        if (fp)
            put(fp, 32);
        if (packFp)
            put(packFp, PACK_FP_BYTES);
        for (var j = 0; j < name.length; j++)
            b[at++] = name.charCodeAt(j);
        return lib.toHex(b);
    }

    // null when the host runs no mod and no pack, { fp, name, pack } with
    // null for what it doesn't run, or { bad: true } for a tail this page
    // can't read, such as one from a page before the pack was in it.
    function parseTail(hex) {
        hex = String(hex || '');
        if (!hex)
            return null;
        if (hex.length % 2 || !/^[0-9a-fA-F]+$/.test(hex) || hex.length < 2 * 7)
            return { bad: true };
        var b = new Uint8Array(hex.length / 2);
        for (var i = 0; i < b.length; i++)
            b[i] = parseInt(hex.substr(i * 2, 2), 16);
        var flags = b[5];
        var size = 7 + (flags & TAIL_MOD ? 32 : 0) + (flags & TAIL_PACK ? PACK_FP_BYTES : 0) + b[6];
        if (b[0] !== TAIL_MAGIC[0] || b[1] !== TAIL_MAGIC[1] || b[2] !== TAIL_MAGIC[2] ||
            b[3] !== TAIL_MAGIC[3] || b[4] !== TAIL_VERSION || !flags || flags & ~(TAIL_MOD | TAIL_PACK) ||
            b[6] > MAX_NAME || !(flags & TAIL_MOD) !== !b[6] || b.length !== size)
            return { bad: true };
        var at = 7;
        var fp = null, pack = null;
        if (flags & TAIL_MOD) {
            fp = lib.toHex(b.subarray(at, at + 32));
            at += 32;
        }
        if (flags & TAIL_PACK) {
            pack = lib.toHex(b.subarray(at, at + PACK_FP_BYTES));
            at += PACK_FP_BYTES;
        }
        var name = '';
        for (var j = 0; j < b[6]; j++)
            name += String.fromCharCode(b[at + j]);
        return { fp: fp, name: fp ? cleanName(name) : null, pack: pack };
    }

    // ---- Which mod this tab runs, and the mods it could switch to.

    var current = null;   // { fp, name, path, lib } of the running mod, or null; lib is
                          // the Mod Library's id for it when it saved it (findLib)
    var target = null;    // where the next restart goes, the same shape
    var fingerprints = {}; // path -> Promise<fp>
    var sigs = {};        // path -> the file parts its fingerprint was worked out from
    var unpacked = {};    // netmods folder name -> fp, this session

    // Mod folders the page found and loaded: [{ name, path }], path relative
    // to the game folder.
    function folders() {
        return Array.isArray(Module.jkModFolders) ? Module.jkModFolders : [];
    }

    // The fingerprint of the mod folder at path, under the game folder root.
    async function fingerprintAt(root, path) {
        var p = packPieces(listFiles(root + '/' + path), readMod);
        var fp = await lib.sha256(p.data.bytes());
        sigs[path] = fileParts(p);
        return fp;
    }

    function fingerprint(path) {
        if (!fingerprints[path]) {
            fingerprints[path] = fingerprintAt(core.gameRoot(), path);
            fingerprints[path].catch(function() { delete fingerprints[path]; });
        }
        return fingerprints[path];
    }

    // A mod unpacked as fp at path: its files are the pack's, so the
    // fingerprint holds without working it out again.
    function unpackedAs(root, path, fp) {
        unpacked[path] = fp;
        fingerprints[path] = Promise.resolve(fp);
        try {
            sigs[path] = fileParts(packPieces(listFiles(root + '/' + path), readMod));
        } catch (e) {
            delete sigs[path];
        }
    }

    function netPath(fp) {
        return 'netmods/' + fp.substring(0, 16);
    }

    // The Mod Library's id for the running mod, if the library saved it in
    // this browser (its record says), worked out once the mod is set: the
    // host's keyframe says it (libId), so a game watching that doesn't have
    // the mod can get it from the library.
    function findLib() {
        var c = current;
        if (!c || !c.fp || c.lib != null)
            return;
        store.list(gameName()).then(function(metas) {
            for (var m of metas) {
                if (m.sha256 === c.fp && m.lib != null) {
                    c.lib = String(m.lib);
                    return;
                }
            }
        }, function() {});
    }

    function libId() {
        return current && current.fp && current.lib != null ? String(current.lib) : '';
    }

    function nameOfPath(path) {
        for (var f of folders()) {
            if (f.path === path)
                return f.name;
        }
        var parts = path.split('/');
        return parts[parts.length - 1];
    }

    // Saved from an earlier game: unpacked into netmods/, after checking it's
    // still what was saved.
    async function fromStore(root, fp, name) {
        var saved = null;
        try { saved = await store.find(gameName(), fp); } catch (e) {}
        if (!saved)
            return null;
        var bytes = new Uint8Array(saved.data);
        if (await lib.sha256(bytes) !== fp)
            return null;
        var path = netPath(fp);
        unpack(bytes, root + '/' + path);
        unpackedAs(root, path, fp);
        return { fp: fp, name: cleanName(name || saved.meta.name), path: path };
    }

    // ---- The Remastered pack.

    var PACK_NAME = 'jkmremasteredassets.goo';
    var PACK_TITLE = 'MotS Remastered pack';
    // The folders the engine loads it from (jkRes_LoadNew), and the one it
    // waits in while this tab runs without it, which the engine doesn't read.
    var PACK_DIRS = ['mods', 'resource'];
    var PACK_OFF_DIR = 'jkpack-off';

    // The pack in the picked folder, worked out before the engine starts:
    // { fp, dir, file, root, on }, its fingerprint, the folder it loads from
    // and its name there, the game folder, and whether it's loaded. null for
    // a player without it.
    var remaster = null;

    function packRunning() {
        return remaster && remaster.on ? remaster.fp : null;
    }

    // Moves the pack where the engine loads it from, or out of its way, for
    // the engine's next start.
    function setPack(on) {
        if (!remaster || remaster.on === on)
            return;
        var off = remaster.root + '/' + PACK_OFF_DIR;
        var from = (remaster.on ? remaster.dir : off) + '/' + remaster.file;
        var to = (on ? remaster.dir : off) + '/' + remaster.file;
        try {
            FS().mkdirTree(on ? remaster.dir : off);
            FS().rename(from, to);
            remaster.on = on;
            console.log('OpenJKDF2: ' + (on ? 'loading the ' : 'leaving out the ') + PACK_TITLE);
        } catch (e) {
            console.warn('OpenJKDF2: could not move the ' + PACK_TITLE + ': ' + e);
        }
    }

    // ---- Host.

    function tail() {
        var fp = current && current.fp ? current.fp : null;
        var pack = packRunning();
        return fp || pack ? encodeTail(fp, fp ? current.name : null, pack) : '';
    }

    function host() {
        var c = current;
        if (!c || !c.fp) {
            core.withdraw(KIND_MOD);
            return;
        }
        core.offer(KIND_MOD, async function() {
            var root = core.gameRoot();
            var ext = gameExt();
            var info = { status: 'error', name: c.name, ext: ext };
            var p;
            try {
                p = packPieces(listFiles(root + '/' + c.path), readMod);
            } catch (e) {
                info.status = e.reason || 'error';
                return { info: info };
            }
            if (p.entries.length > MAX_MOD_FILES) {
                info.status = 'too-many-files';
                return { info: info };
            }
            if (p.entries.reduce(function(n, e) { return n + e.size; }, 0) > MAX_MOD_BYTES) {
                info.status = 'too-big';
                return { info: info };
            }
            // The files the fingerprint was worked out from, untouched since,
            // still give it; anything else is packed whole to check.
            var sha = sameParts(sigs[c.path], fileParts(p)) ? c.fp : await lib.sha256(p.data.bytes());
            if (sha !== c.fp) {
                info.status = 'changed';
                return { info: info };
            }
            var plan = await lib.planShareRanges(p.data, shareRanges(p), core.retailSources(root, ext));
            if (!plan.ok) {
                info.status = plan.reason;
                return { info: info };
            }
            console.log('OpenJKDF2: ready to send mod ' + c.name + ' to joiners (' + p.entries.length + ' files, ' +
                        plan.refs + ' parts left out as original game files, ' + plan.stream.length + ' of ' +
                        p.data.length + ' bytes to send)');
            return {
                info: { status: 'ok', name: c.name, ext: ext, size: p.data.length, sha256: sha,
                        streamSize: plan.stream.length, refsBytes: plan.refsBytes },
                stream: plan.stream
            };
        });
    }

    function unhost() {
        core.withdraw(KIND_MOD);
    }

    // A game watching this host's match asked its feed for the mod with
    // fingerprint fp (stdComm_WSRelay.c): this host's mod goes to feedUrl
    // (its https address and token) if it's that one. alive() says whether
    // that's still the host's feed.
    function feedUp(feedUrl, fp, alive) {
        if (!current || current.fp !== fp)
            return false;
        return core.feedUp(KIND_MOD, feedUrl, fp, alive);
    }

    // ---- Joiner.

    var MESSAGES = {
        'none': "The host's mod couldn't be read on their side.",
        'error': "The host couldn't get its mod ready to send.",
        'too-big': 'This mod is over 1 GB, too big to send. To join, put your own copy of it in your game folder.',
        'memory': "This tab ran out of memory for the host's mod. Close other tabs and try again, or put your " +
                  'own copy of it in your game folder.',
        'too-many-files': 'This mod has too many files to send.',
        'retail-only': "The host's mod is made only of original game files, so it isn't sent.",
        'corrupt': "The mod didn't arrive intact, so it wasn't installed.",
        'mismatch': "The mod didn't arrive intact, so it wasn't installed.",
        'install': "The mod couldn't be set up in this tab.",
        'bad-files': "The host's mod has file names that can't be saved here, so it wasn't installed.",
        'changed': "The host's mod files changed after their game started. They need to reload the page.",
        'other-mod': 'The host is running a different mod now.',
        'unreadable': "This game's mod details couldn't be read. One of you may need to reload the page.",
        'pack-missing': 'This game uses the MotS Remastered pack, which your game folder doesn\'t have. To join, ' +
                        "put JKMRemasteredAssets.goo in your game folder's Mods folder, then reload this page " +
                        'and pick the folder again.',
        'pack-other': "Your MotS Remastered pack is a different version from the host's. To join, you both " +
                      'need the same JKMRemasteredAssets.goo.'
    };

    function messageFor(reason) {
        var ext = gameExt();
        if (reason === 'other-game')
            return 'This game is for ' + gameTitle(ext === 'goo' ? 'gob' : 'goo') +
                   ', and the game folder you picked is ' + gameTitle(ext) + '.';
        if (reason === 'missing-retail')
            return 'This mod uses original ' + gameTitle(ext) +
                   " files that weren't found in the game folder you picked.";
        if (reason in MESSAGES)
            return MESSAGES[reason];
        if (/^(no-answer|stalled|host-left|lobby-lost|cancelled)$/.test(reason))
            return undefined; // worded the same as for maps
        return "The host's mod couldn't be sent (" + reason + ').';
    }

    function fetchMod(tailHex) {
        var want = parseTail(tailHex);
        core.startJob(KIND_MOD, {
            want: want,
            label: want && !want.bad ? want.name || PACK_TITLE : 'Unknown mod',
            ext: gameExt(),
            messageFor: messageFor
        }, runJob);
    }

    function cancel() {
        core.abort('cancelled', KIND_MOD);
    }

    var REJOIN = ' When the main menu is back, join from Multiplayer again: this game will already be selected.';

    // The graphics packs this player ticked (index.html), by name.
    function graphicsPacks() {
        return Array.isArray(Module.jkGraphicsPacks) ? Module.jkGraphicsPacks : [];
    }

    function graphicsText() {
        var p = graphicsPacks();
        if (!p.length)
            return '';
        return p.length === 1 ? ' Your graphics pack, ' + p[0] + ', stays on.' :
               ' Your graphics packs (' + p.join(', ') + ') stay on.';
    }

    async function runJob(j) {
        var want = j.want;
        if (want && want.bad)
            throw fail('unreadable');
        var wantFp = want ? want.fp : null;
        var wantPack = want ? want.pack : null;
        var have = current && current.fp ? current.fp : null;
        var havePack = packRunning();
        if (wantPack && wantPack !== havePack) {
            if (!remaster)
                throw fail('pack-missing');
            if (remaster.fp !== wantPack)
                throw fail('pack-other');
        }
        if (wantFp === have && wantPack === havePack)
            return core.STATE_READY;

        // The pack only changes with a restart, so it goes with the mod's.
        var packText = (wantPack === havePack ? '' : wantPack ?
            ' It also loads your ' + PACK_TITLE + ', which the host uses.' :
            " It also leaves out your " + PACK_TITLE + ", which the host doesn't use.") + graphicsText();
        var found;
        if (wantFp === have) {
            found = current ? { fp: current.fp, name: current.name, path: current.path } : { fp: null, name: null, path: '' };
            core.ui.notice(wantPack ? 'Restarting with the Remastered pack' : 'Restarting without the Remastered pack',
                           PACK_TITLE,
                           (wantPack ? 'The host uses the ' + PACK_TITLE + ', so the game restarts to load yours.' :
                            "The host doesn't use the " + PACK_TITLE + ', so the game restarts without yours, ' +
                            'since every player has to run the same files.') + graphicsText() + REJOIN);
        } else if (!wantFp) {
            found = { fp: null, name: null, path: '' };
            core.ui.notice('Restarting without your mod', current.name,
                           "The host isn't using a mod, so the game restarts without yours." + packText + REJOIN);
        } else {
            found = await findLocal(j, want);
            if (!found) {
                var info = await askHost(j, want);
                found = await findBySize(j, want, info) || await download(j, want, info);
            }
            if (!found.downloaded)
                console.log('OpenJKDF2: using mod ' + want.name + ' from ' + found.path);
            core.check(j);
            core.ui.notice("Restarting with the host's mod", want.name,
                           'The game restarts to load it.' + packText + REJOIN);
        }
        found.pack = !!wantPack;
        target = found;
        return core.STATE_RESTART;
    }

    async function matchFolder(j, want, f) {
        var fp = null;
        try { fp = await fingerprint(f.path); } catch (e) {}
        core.check(j);
        return fp === want.fp ? { fp: fp, name: f.name, path: f.path } : null;
    }

    // The host's mod among this player's own, without asking the host:
    // unpacked earlier this session, a mod folder of the same name with the
    // same files, or saved from an earlier game.
    async function findLocal(j, want) {
        var path = netPath(want.fp);
        if (unpacked[path] === want.fp && isDir(core.gameRoot() + '/' + path))
            return { fp: want.fp, name: want.name, path: path };

        var lower = want.name.toLowerCase();
        for (var f of folders()) {
            if (f.name.toLowerCase() === lower) {
                var found = await matchFolder(j, want, f);
                if (found)
                    return found;
            }
        }

        var saved = await fromStore(core.gameRoot(), want.fp, want.name);
        core.check(j);
        return saved;
    }

    // What the host says about its mod. Its size picks out which other mod
    // folders could hold the same files.
    async function askHost(j, want) {
        j.checking = setTimeout(function() {
            if (!j.done)
                core.ui.show(j.label, "Checking the host's mod...", cancel, KIND_MOD);
        }, core.CHECKING_UI_MS);
        j.timers.push(j.checking);
        var info = await core.askInfo(j);
        if (info.status === 'ok') {
            if (info.ext !== gameExt())
                throw fail('other-game');
            core.checkInfo(info, MAX_SEND_BYTES);
            if (info.sha256 !== want.fp)
                throw fail('other-mod');
        }
        return info;
    }

    // A mod folder under another name with the same files. Packs of the same
    // files are the same size, which listing a folder tells without reading
    // it. When the host can't send its mod there's no size to go by, so
    // every folder is tried.
    async function findBySize(j, want, info) {
        var lower = want.name.toLowerCase();
        for (var f of folders()) {
            if (f.name.toLowerCase() === lower)
                continue;
            if (info.status === 'ok') {
                var size = 0;
                try {
                    var files = listFiles(core.gameRoot() + '/' + f.path);
                    size = 16 + files.length * GOB_ENTRY;
                    for (var file of files)
                        size += file.size;
                } catch (e) {}
                if (size !== info.size)
                    continue;
            }
            var found = await matchFolder(j, want, f);
            if (found)
                return found;
        }
        if (info.status !== 'ok')
            throw fail(info.status);
        return null;
    }

    async function download(j, want, info) {
        var root = core.gameRoot();
        var ext = gameExt();
        clearTimeout(j.checking);
        core.ui.show(j.label, 'Connecting to the host...', cancel, KIND_MOD);
        await core.waitForDirect(j);
        var bytes = await core.receive(j, info, core.retailSources(root, ext));
        var path = netPath(want.fp);
        var count = unpack(bytes, root + '/' + path);
        unpackedAs(root, path, want.fp);
        console.log('OpenJKDF2: installed mod ' + want.name + ' from the host (' + count + ' files)');
        store.put(gameName(), want.name, ext, want.fp, bytes).catch(function(e) {
            console.warn('OpenJKDF2: could not save mod ' + want.name + ' for next time: ' + e);
        });
        return { fp: want.fp, name: want.name, path: path, downloaded: true };
    }

    // Called by the engine as it restarts into the target: the path to give
    // it, which is now the running mod.
    function restart() {
        var t = target;
        target = null;
        current = t && t.fp ? { fp: t.fp, name: t.name, path: t.path } : null;
        if (t)
            setPack(!!t.pack);
        findLib();
        return t ? t.path : '';
    }

    // One line for the join screen about the selected game's mod.
    function describe(tailHex) {
        var want = parseTail(tailHex);
        var have = current && current.fp ? current : null;
        // The page names several mods "A + B + C", ending in "+ N more" when
        // that's too long. Shortened, that's the first and how many more.
        function several(n) { return n.split(' + ').length > 1; }
        function short(n) {
            if (n.length <= 24)
                return n;
            var parts = n.split(' + ');
            if (parts.length < 2)
                return n.substring(0, 23) + '...';
            var more = parts.length - 1;
            var m = /^(\d+) more$/.exec(parts[parts.length - 1]);
            if (m)
                more += Number(m[1]) - 1;
            var rest = ' + ' + more + ' more';
            var first = parts[0];
            return (first.length > 24 - rest.length ? first.substring(0, 21 - rest.length) + '...' : first) + rest;
        }
        if (want && want.bad)
            return 'Mod: unknown';
        var wantPack = want ? want.pack : null;
        if (wantPack && !remaster)
            return 'Needs the MotS Remastered pack';
        if (wantPack && remaster.fp !== wantPack)
            return "Needs the host's version of the Remastered pack";

        var mod = '', modWhy = '';
        if (want && want.fp) {
            mod = (several(want.name) ? 'Mods: ' : 'Mod: ') + short(want.name);
            if (!have || want.fp !== have.fp)
                modWhy = several(want.name) ? ' (the game restarts to load them)' : ' (the game restarts to load it)';
        } else if (have) {
            mod = 'No mod';
            modWhy = ' (the game restarts without ' + short(have.name) + ')';
        }
        var havePack = packRunning();
        var pack = '', packWhy = '';
        if (wantPack) {
            pack = 'Remastered pack';
            if (!havePack)
                packWhy = ' (the game restarts to load it)';
        } else if (havePack) {
            pack = 'No Remastered pack';
            packWhy = ' (the game restarts without it)';
        }
        if (!pack && !mod) {
            // A game without mods, for a player with graphics packs.
            var p = graphicsPacks();
            return !p.length ? '' : p.length === 1 ? 'Your graphics pack stays on' : 'Your graphics packs stay on';
        }
        if (!pack)
            return mod + modWhy;
        if (!mod)
            return pack + packWhy;
        return mod + ', ' + (wantPack ? 'Remastered pack' : 'no Remastered pack') +
               (modWhy || packWhy ? ' (the game restarts)' : '');
    }

    // ---- A game watching a match (stdComm_WSRelay.c's view) whose mod or
    // Remastered pack isn't the match's: the host's (or none) as the host
    // runs them, for the engine to restart into. The host's mod comes from the
    // player's own (findLocal, then any other mod folder with the same files),
    // the Mod Library's, when the host's keyframe names it (lib), or the
    // host's game by way of the match's feed (feed: its https address, and
    // ask(fp) to ask it). It shows no panel (quiet): onProgress(done, total,
    // from) says how far along a download is, from 'library' or 'host' (total
    // 0 while the host's game is asked), and viewError() why it couldn't.

    var viewJob = null;

    function viewMessageFor(reason, want) {
        var name = want && want.name ? want.name : 'its mod';
        var how = ' To watch it, put the same mod in your game folder, or join a match played with it once.';
        switch (reason) {
        case 'unreadable':
            return "This match is played with a mod this game can't read.";
        case 'pack-missing':
            return "This match is played with the MotS Remastered pack, which your game folder doesn't have.";
        case 'pack-other':
            return 'Your MotS Remastered pack is a different version from the one this match is played with.';
        case 'not-found':
        case 'library-missing':
            return 'This match is played with ' + name + ", which your game doesn't have and the Mod Library " +
                   "doesn't either." + how;
        case 'library-other':
            return "The Mod Library's copy of " + name + " isn't the version this match is played with." + how;
        case 'library-error':
            return "The Mod Library couldn't be reached to get " + name + '. Try again in a minute.';
        case 'host-silent':
            return "The host's game didn't send " + name + ". It may be on an older version of the page." + how;
        case 'host-stalled':
            return "The host's game stopped sending " + name + '. Try again in a minute.';
        case 'too-big':
            return name + ' is over 1 GB, too big to send.' + how;
        case 'too-many-files':
            return name + ' has too many files to send.' + how;
        case 'changed':
            return "The host's mod files changed after their game started, so " + name + " can't be sent.";
        case 'retail-only':
            return name + ' is made only of original game files, so it isn\'t sent.' + how;
        case 'other-mod':
            return 'The host is running a different mod now.';
        case 'corrupt':
        case 'mismatch':
            return name + " didn't arrive intact. Try again in a minute.";
        case 'memory':
            return 'This tab ran out of memory for ' + name + '. Close other tabs and try again.';
        case 'bad-files':
        case 'install':
            return name + " couldn't be set up in this tab.";
        case 'cancelled':
            return '';
        }
        return "This game couldn't get " + name + ' to watch this match (' + reason + ').';
    }

    function viewFetch(tailHex, libIdArg, onProgress, feed) {
        var want = parseTail(tailHex);
        viewJob = core.startJob(KIND_MOD, {
            want: want,
            lib: libIdArg != null && libIdArg !== '' ? String(libIdArg) : '',
            feed: feed && typeof feed.url === 'string' && feed.url && typeof feed.ask === 'function' ? feed : null,
            label: want && !want.bad ? want.name || PACK_TITLE : 'Unknown mod',
            ext: gameExt(),
            quiet: true,
            messageFor: function(reason) { return viewMessageFor(reason, want); },
            onProgress: onProgress || function() {}
        }, runViewJob);
    }

    function viewError() {
        return viewJob && viewJob.errorText || '';
    }

    async function runViewJob(j) {
        var want = j.want;
        if (want && want.bad)
            throw fail('unreadable');
        var wantFp = want ? want.fp : null;
        var wantPack = (want && want.pack) || null;
        var have = current && current.fp ? current.fp : null;
        var havePack = packRunning() || null;
        if (wantPack && wantPack !== havePack) {
            if (!remaster)
                throw fail('pack-missing');
            if (remaster.fp !== wantPack)
                throw fail('pack-other');
        }
        if (wantFp === have && wantPack === havePack)
            return core.STATE_READY;
        var found;
        if (wantFp === have) {
            found = current ? { fp: current.fp, name: current.name, path: current.path } : { fp: null, name: null, path: '' };
        } else if (!wantFp) {
            found = { fp: null, name: null, path: '' };
        } else {
            found = await findLocal(j, want);
            // The Mod Library's failing, the host's game may still send it.
            var libFailed = null;
            if (!found && j.lib) {
                try {
                    found = await fromLibrary(j, want);
                } catch (e) {
                    if (!j.feed || !e.reason || e.reason === 'cancelled')
                        throw e;
                    libFailed = e;
                }
            }
            if (!found)
                found = await findAnyFolder(j, want);
            if (!found && j.feed)
                found = await fromHost(j, want);
            if (!found)
                throw libFailed || fail(j.lib ? 'library-missing' : 'not-found');
            if (!found.downloaded)
                console.log('OpenJKDF2: watching with mod ' + want.name + ' from ' + found.path);
        }
        core.check(j);
        var what = found.fp ? 'with mod ' + found.name : 'without a mod';
        if (wantPack)
            what += ', with the ' + PACK_TITLE;
        else if (havePack)
            what += ', without the ' + PACK_TITLE;
        console.log('OpenJKDF2: restarting ' + what + ', to watch a match');
        found.pack = !!wantPack;
        target = found;
        return core.STATE_RESTART;
    }

    // Every other mod folder of the player's, for the same files under
    // another name.
    async function findAnyFolder(j, want) {
        var lower = want.name.toLowerCase();
        for (var f of folders()) {
            if (f.name.toLowerCase() === lower)
                continue;
            var found = await matchFolder(j, want, f);
            if (found)
                return found;
        }
        return null;
    }

    // The host's mod from the Mod Library (modlibrary.js viewGet), which
    // saves it in this browser as Get Mod does. null when it doesn't list
    // that id any more.
    async function fromLibrary(j, want) {
        var ml = Module.jkModLibrary;
        if (!ml || typeof ml.viewGet !== 'function')
            return null;
        var stop = new AbortController();
        j.cancel = function() { stop.abort(); };
        var got;
        try {
            got = await ml.viewGet(gameName(), j.lib, function(done, total) { j.onProgress(done, total, 'library'); },
                                   stop.signal);
        } catch (e) {
            core.check(j);
            console.log('OpenJKDF2: could not get mod ' + want.name + ' from the Mod Library (' + (e && e.message || e) + ')');
            throw fail('library-error');
        }
        core.check(j);
        if (!got || !got.fp)
            return null;
        if (got.fp !== want.fp)
            throw fail('library-other');
        var root = core.gameRoot();
        var path = netPath(want.fp);
        var count = unpack(got.bytes, root + '/' + path);
        unpackedAs(root, path, want.fp);
        console.log('OpenJKDF2: installed mod ' + want.name + ' from the Mod Library (' + j.lib + ', ' + count +
                    ' files), to watch a match');
        return { fp: want.fp, name: want.name, path: path, downloaded: true };
    }

    // The host's mod from the host's game, by way of the match's feed
    // (maps.js feedGet), checked as a joiner checks it, then saved in this
    // browser as one from a host is.
    async function fromHost(j, want) {
        var root = core.gameRoot();
        var ext = gameExt();
        var src = { base: j.feed.url + '/mod/' + want.fp + '/', ask: function() { j.feed.ask(want.fp); } };
        var bytes = await core.feedGet(j, src, function(info) {
            if (info.ext !== ext)
                throw fail('other-game');
            core.checkInfo(info, MAX_SEND_BYTES);
            if (info.sha256 !== want.fp)
                throw fail('other-mod');
        }, function(done, total) { j.onProgress(done, total, 'host'); });
        core.check(j);
        var path = netPath(want.fp);
        var count;
        try {
            count = unpack(bytes, root + '/' + path);
        } catch (e) {
            throw fail(e.reason || 'install');
        }
        unpackedAs(root, path, want.fp);
        console.log('OpenJKDF2: installed mod ' + want.name + " from the host's game (" + count + ' files), to watch a match');
        store.put(gameName(), want.name, ext, want.fp, bytes).catch(function(e) {
            console.warn('OpenJKDF2: could not save mod ' + want.name + ' for next time: ' + e);
        });
        return { fp: want.fp, name: want.name, path: path, downloaded: true };
    }

    // ---- The Mod Library's (modlibrary.js): the mods it saved in this
    // browser, which carry its id (lib), and getting the engine ready to start
    // again with one. Saved here, a mod is also one a joiner can use when the
    // host runs it (fromStore), and one the page can unpack.

    async function libraryList(game) {
        var metas = [];
        try { metas = await store.list(game); } catch (e) {}
        return metas.filter(function(m) { return m.lib != null; });
    }

    function librarySave(game, name, ext, fp, bytes, extra) {
        return store.put(game, cleanName(name), ext, fp, bytes, extra);
    }

    // The next restart's mod: the pack with fingerprint fp (bytes, or the one
    // saved here), unpacked into netmods/ as a mod from a host is. A graphics
    // pack (asPack) is unpacked into mods/ instead, which the engine loads
    // whatever mod it runs, and the running mod stays. The Remastered pack
    // stays as it is. Resolves to the path the engine restarts in.
    async function libraryPrepare(fp, name, bytes, asPack) {
        var root = core.gameRoot();
        if (!bytes) {
            var saved = await store.find(gameName(), fp);
            if (!saved)
                throw fail('not-saved');
            bytes = new Uint8Array(saved.data);
        }
        if (await lib.sha256(bytes) !== fp)
            throw fail('corrupt');
        var keepPack = !!(remaster && remaster.on);
        if (asPack) {
            unpack(bytes, root + '/mods');
            target = current ? { fp: current.fp, name: current.name, path: current.path, pack: keepPack }
                             : { fp: null, name: null, path: '', pack: keepPack };
            return target.path;
        }
        var path = netPath(fp);
        unpack(bytes, root + '/' + path);
        unpackedAs(root, path, fp);
        target = { fp: fp, name: cleanName(name), path: path, pack: keepPack };
        return path;
    }

    Module.jkMods = {
        lib: { pack: pack, packFiles: packFiles, unpack: unpack, shareRanges: shareRanges, listFiles: listFiles,
               encodeTail: encodeTail, parseTail: parseTail, validRel: validRel, packable: packable },
        tail: tail,
        host: host,
        unhost: unhost,
        feedUp: feedUp,
        fetch: fetchMod,
        abort: function(reason) { core.abort(reason, KIND_MOD); },
        state: function() { return core.state(KIND_MOD); },
        restart: restart,
        describe: describe,
        current: function() { return current; },
        libId: libId,
        viewFetch: viewFetch,
        viewError: viewError,
        library: { list: libraryList, save: librarySave, prepare: libraryPrepare }
    };

    // Works out which mod the engine starts with, from -path: a mod folder the
    // page loaded, or a mod saved from an earlier game, which is unpacked
    // first. Its fingerprint is needed before anyone can host or join.
    function pathArg() {
        var args = Module['arguments'] || [];
        for (var i = 0; i < args.length - 1; i++) {
            if (/^[-\/]path$/i.test(args[i]))
                return args[i + 1];
        }
        return null;
    }

    Module.preRun = Module.preRun || [];
    if (typeof Module.preRun === 'function')
        Module.preRun = [Module.preRun];

    // Finds the Remastered pack where the engine loads it from, and its
    // fingerprint, which is needed before anyone can host or join.
    Module.preRun.push(function() {
        if (!isMots())
            return;
        var root = '/mots';
        var found = null;
        for (var d of PACK_DIRS) {
            var dir = core.findPath(root, d);
            var names = [];
            try { names = dir ? FS().readdir(dir) : []; } catch (e) {}
            for (var n of names) {
                if (n.toLowerCase() === PACK_NAME && core.isFile(dir + '/' + n)) {
                    found = { dir: dir, file: n };
                    break;
                }
            }
            if (found)
                break;
        }
        if (!found)
            return;
        Module.addRunDependency('jk-remaster');
        (async function() {
            var fp = (await lib.sha256(FS().readFile(found.dir + '/' + found.file))).substring(0, 2 * PACK_FP_BYTES);
            remaster = { fp: fp, dir: found.dir, file: found.file, root: root, on: true };
            // Watching a match played without it (index.html's playWatched):
            // this run leaves it out, as a joiner's restart for such a match
            // does, so its files are the match's.
            var watchPack = Module.jkWatchPack;
            delete Module.jkWatchPack;
            if (watchPack === false) {
                setPack(false);
                return;
            }
            console.log('OpenJKDF2: running the ' + PACK_TITLE + ' (' + fp + ')');
        })().catch(function(e) {
            // Without a fingerprint it can't be matched with the host's, so
            // this tab runs without it.
            console.warn('OpenJKDF2: could not read the ' + PACK_TITLE + ', so it is left out: ' + e);
            remaster = { fp: null, dir: found.dir, file: found.file, root: root, on: true };
            setPack(false);
            remaster = null;
        }).finally(function() {
            Module.removeRunDependency('jk-remaster');
        });
    });

    Module.preRun.push(function() {
        var path = pathArg();
        if (!path)
            return;
        path = path.replace(/\\/g, '/').replace(/^\.\//, '').replace(/\/+$/, '');
        Module.addRunDependency('jk-mods');
        (async function() {
            var root = isMots() ? '/mots' : '/jk1';
            var m = /^netmods\/([0-9a-f]{16})$/.exec(path);
            if (m && !isDir(root + '/' + path)) {
                var metas = [];
                try { metas = await store.list(gameName()); } catch (e) {}
                metas.sort(function(a, b) { return b.used - a.used; });
                for (var meta of metas) {
                    if (meta.sha256.substring(0, 16) === m[1]) {
                        current = await fromStore(root, meta.sha256, meta.name);
                        break;
                    }
                }
                if (!current)
                    console.warn('OpenJKDF2: the saved mod ' + path + " couldn't be loaded from this browser's storage");
            } else if (isDir(root + '/' + path)) {
                var fp = await fingerprintAt(root, path);
                fingerprints[path] = Promise.resolve(fp);
                current = { fp: fp, name: cleanName(nameOfPath(path)), path: path };
            } else {
                console.warn('OpenJKDF2: no mod folder at ' + path);
            }
            if (current) {
                console.log('OpenJKDF2: running mod ' + current.name + ' (' + current.fp.substring(0, 16) + ')');
                findLib();
            }
        })().catch(function(e) {
            current = null;
            console.warn('OpenJKDF2: could not read the mod in ' + path + ': ' + e);
        }).finally(function() {
            Module.removeRunDependency('jk-mods');
        });
    });
})();
