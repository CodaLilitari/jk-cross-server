#!/usr/bin/env python3
"""Activate Emscripten 6.0.12, modify libsmacker, then run this script."""
from pathlib import Path
import json, subprocess
root = Path(__file__).resolve().parent
config = json.loads((root / "link.json").read_text())
for name in ("smacker", "smk_bitstream", "smk_hufftree"):
    subprocess.run(["emcc", *config["compile_args"], "-c", "libsmacker/"+name+".c",
        "-o", "CMakeFiles/sith_engine.dir/src/external/libsmacker/"+name+".c.o"], cwd=root, check=True)
subprocess.run(config["link"], cwd=root, check=True)
print(root / "openjkdf2.wasm")
